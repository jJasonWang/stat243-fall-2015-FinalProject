library(testthat)
library(ars)

test_check("ars")
