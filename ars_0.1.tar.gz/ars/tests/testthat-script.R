library(testthat)
library(ars)

test_package('ars','main')
test_package('ars','unit')
